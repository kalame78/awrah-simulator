import React, { useState } from 'react';
import { User, Users, Eye, Info } from 'lucide-react';
import { Gender, Relation } from '../types';

const AwrahSimulator: React.FC = () => {
  const [selectedGender, setSelectedGender] = useState<Gender>(Gender.Male);
  const [relation, setRelation] = useState<Relation>(Relation.Ajnabi);

  // Logic based on Fiche 8
  const getRule = (): { title: string; desc: string; visible: string[]; hidden: string[]; note?: string } => {
    if (selectedGender === Gender.Male) {
      if (relation === Relation.Mahram || relation === Relation.SameGender) {
        return {
          title: "Entre Hommes ou avec Mahram",
          desc: "Ce qu'il y a entre le nombril et les genoux doit être couvert.",
          visible: ["Tête", "Torse", "Bras", "Jambes (sous genoux)"],
          hidden: ["Zone entre Nombril et Genoux"],
          note: "Hadith: 'La 'awrah de l'homme est ce qu'il y a entre son nombril et ses genoux'"
        };
      } else if (relation === Relation.Ajnabi) {
        return {
          title: "Face à une femme Ajnabiyyah (Étrangère)",
          desc: "Le regard est limité. Préserver le regard est la priorité.",
          visible: ["Visage (pour identification si nécessaire)", "Mains (selon avis)"],
          hidden: ["Tout le corps"],
          note: "Selon l'avis présenté: 'Tout sauf le visage et les mains' (si pas de fitna), ou 'Tout le corps sauf visage/mains' pour le regard."
        };
      } else if (relation === Relation.Spouse) {
        return {
          title: "Avec son épouse",
          desc: "Aucune restriction.",
          visible: ["Tout le corps"],
          hidden: ["Aucune partie"],
        };
      }
    } else {
      // Female Logic
      if (relation === Relation.SameGender) {
        return {
          title: "Entre Femmes Musulmanes",
          desc: "Ce qu'il y a entre le nombril et les genoux doit être couvert.",
          visible: ["Tête", "Haut du corps", "Jambes (bas)"],
          hidden: ["Zone entre Nombril et Genoux"],
        };
      } else if (relation === Relation.NonMuslim) {
        return {
          title: "Face à une femme non-musulmane",
          desc: "Il y a divergence. L'avis présenté recommande la prudence comme avec un Mahram.",
          visible: ["Tête", "Extrémités"],
          hidden: ["Le reste du corps"],
          note: "Attention: Les non-musulmanes ne décrivent pas la femme aux hommes."
        };
      } else if (relation === Relation.Mahram) {
        return {
          title: "Face à un Mahram (Père, Frère, Fils...)",
          desc: "Tout sauf la tête et les extrémités des membres.",
          visible: ["Tête", "Cou", "Mains", "Pieds", "Avant-bras"],
          hidden: ["Torse", "Dos", "Ventre", "Cuisses", "Genoux"],
          note: "Le Mahram est celui qu'elle ne peut épouser à jamais (lien sang, alliance, lait)."
        };
      } else if (relation === Relation.Ajnabi) {
        return {
          title: "Face à un homme Ajnabi (Étranger)",
          desc: "Tout le corps est 'awrah.",
          visible: ["Visage (selon avis et nécessité)", "Mains (selon avis)"],
          hidden: ["Tout le corps (Cheveux, Cou, Bras, Formes...)"],
          note: "Le verset 31 de sourate an-Nur énumère les exceptions."
        };
      } else if (relation === Relation.Spouse) {
         return {
          title: "Avec son époux",
          desc: "Aucune restriction.",
          visible: ["Tout le corps"],
          hidden: ["Aucune partie"],
        };
      }
    }
    return { title: "", desc: "", visible: [], hidden: [] };
  };

  const rule = getRule();

  return (
    <div className="grid lg:grid-cols-12 gap-6 animate-fade-in">
      {/* Controls */}
      <div className="lg:col-span-4 space-y-6">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-200">
          <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
            <User size={20} className="text-emerald-600" />
            1. Qui êtes-vous ?
          </h3>
          <div className="flex gap-4">
            <button
              onClick={() => setSelectedGender(Gender.Male)}
              className={`flex-1 py-3 px-4 rounded-xl transition-all font-medium border-2 ${
                selectedGender === Gender.Male
                  ? 'border-emerald-500 bg-emerald-50 text-emerald-700'
                  : 'border-transparent bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              Homme
            </button>
            <button
              onClick={() => setSelectedGender(Gender.Female)}
              className={`flex-1 py-3 px-4 rounded-xl transition-all font-medium border-2 ${
                selectedGender === Gender.Female
                  ? 'border-emerald-500 bg-emerald-50 text-emerald-700'
                  : 'border-transparent bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              Femme
            </button>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-200">
          <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
            <Eye size={20} className="text-emerald-600" />
            2. Qui est en face ?
          </h3>
          <div className="space-y-2">
            {(selectedGender === Gender.Male 
              ? [Relation.Ajnabi, Relation.Mahram, Relation.Spouse]
              : [Relation.Ajnabi, Relation.Mahram, Relation.SameGender, Relation.NonMuslim, Relation.Spouse]
            ).map((r) => (
              <button
                key={r}
                onClick={() => setRelation(r)}
                className={`w-full text-left py-3 px-4 rounded-xl transition-all text-sm font-medium border ${
                  relation === r
                    ? 'border-emerald-500 bg-emerald-50 text-emerald-800 shadow-sm'
                    : 'border-gray-100 bg-white text-gray-600 hover:border-emerald-200'
                }`}
              >
                {r}
              </button>
            ))}
          </div>
          
          {relation === Relation.Mahram && (
             <div className="mt-4 p-3 bg-blue-50 text-blue-800 text-xs rounded-lg flex gap-2">
                <Info size={16} className="shrink-0 mt-0.5" />
                <p>Mahram : Père, fils, frère, oncle paternel/maternel, neveux, beau-père, beau-fils, frère de lait...</p>
             </div>
          )}
        </div>
      </div>

      {/* Visualization */}
      <div className="lg:col-span-8">
        <div className="bg-white h-full p-6 rounded-2xl shadow-lg border border-gray-200 flex flex-col">
          <div className="border-b pb-4 mb-4">
            <h2 className="text-2xl font-bold text-gray-800 mb-1">{rule.title}</h2>
            <p className="text-gray-500 text-sm">Règle applicable selon le contexte sélectionné</p>
          </div>

          <div className="flex-1 flex flex-col md:flex-row gap-8 items-center justify-center">
            {/* Silhouette Representation (Abstract CSS) */}
            <div className="relative w-48 h-80 bg-gray-200 rounded-full flex flex-col items-center justify-between overflow-hidden shadow-inner border-4 border-white ring-1 ring-gray-200">
               {/* This is a visual abstraction of zones */}
               <div className={`w-full flex-1 transition-colors duration-500 flex items-center justify-center text-[10px] font-bold text-center p-1
                  ${rule.visible.some(v => v.includes('Tête') || v.includes('Visage')) ? 'bg-emerald-200 text-emerald-800' : 'bg-gray-800 text-gray-400'}`}>
                  Tête
               </div>
               <div className={`w-full flex-[1.5] transition-colors duration-500 flex items-center justify-center text-[10px] font-bold text-center p-1
                   ${rule.visible.some(v => v.includes('Torse') || v.includes('Haut')) || rule.visible.includes('Tout le corps') ? 'bg-emerald-200 text-emerald-800' : 'bg-gray-800 text-gray-400'}`}>
                  Torse / Bras
               </div>
               <div className={`w-full flex-1 transition-colors duration-500 flex items-center justify-center text-[10px] font-bold text-center p-1
                   ${rule.hidden.some(h => h.includes('Nombril') || h.includes('Tout')) && !rule.visible.includes('Tout le corps') ? 'bg-red-900 text-red-200' : 'bg-emerald-200 text-emerald-800'}`}>
                  Zone Awrah Majeure
               </div>
               <div className={`w-full flex-[1.5] transition-colors duration-500 flex items-center justify-center text-[10px] font-bold text-center p-1
                   ${rule.visible.some(v => v.includes('Jambes') || v.includes('Pieds')) || rule.visible.includes('Tout le corps') ? 'bg-emerald-200 text-emerald-800' : 'bg-gray-800 text-gray-400'}`}>
                  Jambes
               </div>
            </div>

            <div className="flex-1 space-y-6">
               <div className="p-4 bg-emerald-50 rounded-lg border-l-4 border-emerald-500">
                 <h4 className="font-bold text-emerald-800 mb-2">Conclusion</h4>
                 <p className="text-emerald-900 text-lg font-medium leading-relaxed">{rule.desc}</p>
               </div>

               <div className="grid grid-cols-2 gap-4">
                 <div className="p-4 bg-green-50 rounded-lg border border-green-100">
                    <h4 className="font-bold text-green-700 mb-2 text-sm uppercase tracking-wide">Visible</h4>
                    <ul className="list-disc list-inside text-sm text-green-800 space-y-1">
                      {rule.visible.map((v, i) => <li key={i}>{v}</li>)}
                    </ul>
                 </div>
                 <div className="p-4 bg-red-50 rounded-lg border border-red-100">
                    <h4 className="font-bold text-red-700 mb-2 text-sm uppercase tracking-wide">Caché (Awrah)</h4>
                    <ul className="list-disc list-inside text-sm text-red-800 space-y-1">
                      {rule.hidden.map((h, i) => <li key={i}>{h}</li>)}
                    </ul>
                 </div>
               </div>

               {rule.note && (
                 <p className="text-xs text-gray-500 italic border-t pt-3">
                   Note: {rule.note}
                 </p>
               )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AwrahSimulator;